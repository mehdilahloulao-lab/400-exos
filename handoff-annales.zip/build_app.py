# Construit la version indépendante (GitHub Pages + Firebase + Gemini) à partir de suivi-400-exos.html
import json, re, shutil, sys, os
src = open('suivi-400-exos.html').read()
cfg = open('app/firebase-config.json').read().strip() if os.path.exists('app/firebase-config.json') else '{"apiKey":"__A_REMPLIR__"}'
t = src
# ---- 0. Contenu du livre retiré du site public : il est importé dans TA base Firebase (privée) ----
i0 = t.index('Object.assign(CONTENT'); i1 = t.index('const PRIO_LEVEL')
seg = t[i0:i1]
import subprocess, tempfile
tf = tempfile.NamedTemporaryFile('w', suffix='.js', delete=False); tf.write('global.CONTENT={};\n' + seg + '\nprocess.stdout.write(JSON.stringify(CONTENT));'); tf.close()
CONTENT = json.loads(subprocess.run(['node', tf.name], capture_output=True, text=True, check=True).stdout)
t = t[:i0] + 'const TITLES = ' + json.dumps({k: v.get('t', '') for k, v in CONTENT.items() if v.get('t')}, ensure_ascii=False) + ';\n' + t[i1:]
t = t.replace('x[2] = (CONTENT[id] && CONTENT[id].t) || x[2] || "";', 'x[2] = (CONTENT[id] && CONTENT[id].t) || TITLES[id] || x[2] || "";')
t = t.replace('if(!CONTENT[id]) li.querySelector(".m span:not(.lv)").textContent', 'if(!CONTENT[id] && !TITLES[id]) li.querySelector(".m span:not(.lv)").textContent')
bych = {}
for k, v in CONTENT.items():
    ch = k.split('-')[0][1:]; bych.setdefault('ch' + ch, {})[k] = v
content_docs = {ch: {"j": json.dumps(d, ensure_ascii=False)} for ch, d in bych.items()}
def rep(old, new, cnt=1):
    global t
    assert t.count(old) == cnt, ("COUNT", t.count(old), old[:90]); t = t.replace(old, new)

# ---- 1. Base de données : Firebase au lieu de Claude ----
rep('''  try{ db = window.claude?.use ? await window.claude.use("db") : null; }catch(e){ db = null; }''',
    '''  try{ db = await appLogin(); }catch(e){ db = null; }''')
# ---- 2. IA : Gemini au lieu de Claude ----
rep('''  try{ sampleFn = window.claude?.use ? await window.claude.use("sample") : null; }catch(e){ sampleFn = null; }''',
    '''  sampleFn = GEM;''')
rep('Avis global de Claude', 'Avis global de Gemini')
rep('par Claude. Il peut se tromper', 'par Gemini. Il peut se tromper')
rep('const ckErr = {', 'const ckErr = {no_key: "Ajoute ta clé Gemini dans Réglages (en bas de l\'accueil).", bad_key: "Clé Gemini refusée : vérifie-la dans Réglages.", overloaded: "Gemini est surchargé : réessaie dans une minute.", network: "Pas de connexion internet.", ')

app_js = r'''
/* ================= Version indépendante : Firebase (synchro) + Gemini (indices, corrections) ================= */
/* Gemini : imite l'interface utilisée par l'app (limits / json) */
const GEM_BASE = "https://generativelanguage.googleapis.com/v1beta";
const lsGet = k => { try{ return localStorage.getItem(k) || ""; }catch(e){ return ""; } };
const lsSet = (k, v) => { try{ v ? localStorage.setItem(k, v) : localStorage.removeItem(k); }catch(e){} };
let gemKey = lsGet("gemkey");
async function blobToB64(b){
  const buf = new Uint8Array(await b.arrayBuffer()); let s = "";
  for(let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return btoa(s);
}
async function gemModels(){
  const cached = lsGet("gemmodels");
  if(cached){ try{ const c = JSON.parse(cached); if(c.k === gemKey.slice(-6) && Date.now() - c.t < 3 * 864e5) return c.m; }catch(e){} }
  let list = [];
  try{
    const r = await fetch(`${GEM_BASE}/models?pageSize=200`, {headers: {"x-goog-api-key": gemKey}});
    if(r.ok){
      const j = await r.json();
      list = (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes("generateContent"))
        .map(m => m.name.replace(/^models\//, ""))
        .filter(n => /flash/.test(n) && !/lite|image|tts|live|audio|embed|exp|8b|latest/.test(n));
      const ver = n => { const m = n.match(/gemini-(\d+)(?:\.(\d+))?/); return m ? +m[1] * 100 + +(m[2] || 0) : 0; };
      list.sort((a, b) => (ver(b) - ver(a)) || ((/preview/.test(a) ? 1 : 0) - (/preview/.test(b) ? 1 : 0)));
    }
  }catch(e){}
  if(!list.includes("gemini-2.5-flash")) list.push("gemini-2.5-flash");
  lsSet("gemmodels", JSON.stringify({k: gemKey.slice(-6), t: Date.now(), m: list}));
  return list;
}
const GEM = async () => ({text: ""});
GEM.limits = async () => ({images: {maxCount: 6, maxInputBytes: 15e6, mediaTypes: ["image/jpeg", "image/png", "image/webp"]}});
GEM.json = async (prompt, opts = {}) => {
  if(!gemKey) throw {code: "no_key"};
  if(!navigator.onLine) throw {code: "network"};
  const parts = [{text: prompt}];
  for(const b of (opts.images || [])) parts.push({inline_data: {mime_type: b.type || "image/jpeg", data: await blobToB64(b)}});
  const body = JSON.stringify({contents: [{role: "user", parts}], generationConfig: {responseMimeType: "application/json", temperature: 0.2}});
  const pinned = lsGet("gemmodel");
  let models = pinned ? [pinned] : await gemModels();
  const ok0 = lsGet("gemok"); if(!pinned && ok0 && models.includes(ok0)) models = [ok0].concat(models.filter(m => m !== ok0));   // le dernier modèle qui a marché d'abord
  let last = {code: "upstream"};
  for(const model of models){
    let r;
    try{ r = await fetch(`${GEM_BASE}/models/${model}:generateContent`, {method: "POST", headers: {"Content-Type": "application/json", "x-goog-api-key": gemKey}, body, signal: opts.signal}); }
    catch(e){ if(e && e.name === "AbortError") throw {code: "cancelled"}; throw {code: "network"}; }
    if(r.ok){
      const j = await r.json();
      const cand = j.candidates && j.candidates[0];
      if(!cand){ throw {code: j.promptFeedback && j.promptFeedback.blockReason ? "refused" : "empty_completion"}; }
      const txt = ((cand.content && cand.content.parts) || []).filter(p => p.text && !p.thought).map(p => p.text).join("");
      if(!txt) throw {code: cand.finishReason === "SAFETY" ? "refused" : "empty_completion"};
      lsSet("gemok", model);
      try{ return JSON.parse(txt); }catch(e){ const m = txt.match(/\{[\s\S]*\}/); if(m){ try{ return JSON.parse(m[0]); }catch(e2){} } throw {code: "invalid_json"}; }
    }
    let msg = ""; try{ msg = JSON.stringify(await r.json()); }catch(e){}
    if(r.status === 400 && /API_KEY_INVALID|API key not valid/i.test(msg)) throw {code: "bad_key"};
    if(r.status === 401 || r.status === 403) throw {code: "bad_key"};
    if(r.status === 503 || r.status === 500){ last = {code: "overloaded"}; continue; }
    if(r.status === 429){ last = {code: "rate_limited"}; if(/limit: 0|free_tier/i.test(msg)) continue; throw last; }   // modèle non gratuit → on essaie le suivant
    if(r.status === 404){ continue; }
    last = {code: "upstream"};
  }
  throw last;
};

/* Connexion (e-mail + mot de passe) puis base Firestore propre à l'utilisateur */
function fbReady(){ return window.FB ? Promise.resolve(window.FB) : new Promise((res, rej) => { window.addEventListener("fb-ready", () => res(window.FB), {once: true}); setTimeout(() => rej(new Error("fb")), 20000); }); }
let fbUser = null;
async function appLogin(){
  const FB = await fbReady();
  const user = await new Promise(res => { const un = FB.onAuth(u => { un(); res(u); }); });
  fbUser = user || await showLogin(FB);
  $("#login").hidden = true;
  const store = FB.db(fbUser.uid);
  // clé Gemini synchronisée entre tes appareils (lisible par toi seul, règles Firestore)
  store.collection("secret").onSnapshot(snap => { snap.docs.forEach(d => { if(d.id === "gemini"){ const v = d.data() || {}; if(v.key && v.key !== gemKey){ gemKey = v.key; lsSet("gemkey", gemKey); renderSettings(); } } }); }, () => {});
  store.collection("content").onSnapshot(snap => {
    snap.docs.forEach(d => { const v = d.data(); if(v && v.j){ try{ Object.assign(CONTENT, JSON.parse(v.j)); }catch(e){} } });
    const empty = !Object.keys(CONTENT).length; $("#rg-msg").textContent = empty ? "Énoncés et corrigés absents : importe le fichier mon-suivi.json dans Réglages." : $("#rg-msg").textContent;
    if(empty){ const r = document.querySelector(".reglages"); if(r) r.open = true; }
    if(openId) openSheet(openId);
  }, () => {});
  window.STORE = store; renderSettings();
  return store;
}
function showLogin(FB){
  return new Promise(res => {
    const box = $("#login"); box.hidden = false;
    const msg = $("#lg-msg"), em = $("#lg-email"), pw = $("#lg-pass");
    const go = async create => {
      msg.textContent = create ? "Création du compte…" : "Connexion…";
      try{ const c = create ? await FB.signUp(em.value.trim(), pw.value) : await FB.signIn(em.value.trim(), pw.value); res(c.user); }
      catch(e){
        const c = (e && e.code) || "";
        msg.textContent = /invalid-credential|wrong-password|user-not-found/.test(c) ? "E-mail ou mot de passe incorrect (première fois ? crée ton compte)." :
          /email-already-in-use/.test(c) ? "Ce compte existe déjà : connecte-toi." : /weak-password/.test(c) ? "Mot de passe trop court (6 caractères minimum)." :
          /invalid-email/.test(c) ? "Adresse e-mail invalide." : /network/.test(c) ? "Pas de connexion internet." : "Connexion impossible : " + c;
      }
    };
    $("#lg-in").onclick = e => { e.preventDefault(); go(false); };
    $("#lg-up").onclick = e => { e.preventDefault(); go(true); };
    $("#lg-reset").onclick = async e => { e.preventDefault(); try{ await FB.reset(em.value.trim()); msg.textContent = "E-mail de réinitialisation envoyé."; }catch(err){ msg.textContent = "Indique d'abord ton e-mail."; } };
  });
}
/* Réglages : clé Gemini, modèle, import, déconnexion */
function renderSettings(){
  const k = $("#rg-key"); if(!k) return;
  $("#rg-keystate").textContent = gemKey ? `Clé enregistrée (…${gemKey.slice(-4)})` : "Aucune clé : les indices et corrections sont désactivés.";
  $("#rg-model").textContent = lsGet("gemmodel") || (lsGet("gemok") ? `automatique (${lsGet("gemok")})` : "automatique");
  $("#rg-user").textContent = fbUser ? fbUser.email : "";
}
document.addEventListener("click", async e => {
  const id = e.target && e.target.id;
  if(id === "rg-save"){
    const v = $("#rg-key").value.trim(); if(!v) return;
    gemKey = v; lsSet("gemkey", v); lsSet("gemmodels", ""); $("#rg-key").value = "";
    if(window.STORE){ try{ await window.STORE.collection("secret").doc("gemini").set({key: v}); }catch(err){} }
    renderSettings();
  }
  if(id === "rg-out" && window.FB){ await window.FB.signOut(); location.reload(); }
  if(id === "rg-test"){
    const st = $("#rg-msg"); st.textContent = "Test en cours…";
    try{ const r = await GEM.json('Réponds uniquement avec ce JSON : {"ok": true}'); st.textContent = r && r.ok ? `Gemini répond (modèle ${lsGet("gemok")}).` : "Réponse inattendue."; }
    catch(err){ st.textContent = ckErr[err && err.code] || "Échec : " + (err && err.code); }
    renderSettings();
  }
});
document.addEventListener("change", async e => {
  if(!e.target || e.target.id !== "rg-import") return;
  const f = e.target.files && e.target.files[0]; const st = $("#rg-msg"); if(!f || !window.FB || !fbUser) return;
  try{
    const data = JSON.parse(await f.text()); st.textContent = "Import en cours…";
    let n = 0, fails = [];
    const order = Object.keys(data).sort((a, b) => (a === "content" ? -1 : 0) - (b === "content" ? -1 : 0));   // énoncés d'abord
    const total = order.reduce((s, c) => s + (data[c] && typeof data[c] === "object" ? Object.keys(data[c]).length : 0), 0);
    for(const col of order){
      const obj = data[col]; if(!obj || typeof obj !== "object") continue;
      for(const [id, v] of Object.entries(obj)){
        try{ await window.STORE.collection(col).doc(id).set(v); n++; }
        catch(err){ fails.push(`${col}/${id} : ${(err && (err.code || err.message)) || err}`); }
        st.textContent = `Import en cours… ${n + fails.length} / ${total}`;
      }
    }
    st.textContent = fails.length ? `Import : ${n} éléments enregistrés, ${fails.length} en échec. ${fails.slice(0, 3).join(" · ")}` : `Import terminé : ${n} éléments (énoncés et corrigés compris).`;
  }catch(err){ st.textContent = "Fichier illisible : " + ((err && err.message) || err); }
  e.target.value = "";
});
'''
rep('/* ---------- Démarrage ---------- */', app_js + '\n/* ---------- Démarrage ---------- */')

# ---- 3. Écran de connexion + réglages ----
login_html = '''
<div class="login" id="login" hidden>
  <form class="lg-card" autocomplete="on">
    <div class="lg-logo"><span></span><span></span><span></span></div>
    <h1>Suivi 400 exos</h1>
    <p class="lg-sub">Connecte-toi pour retrouver ton suivi sur tous tes appareils.</p>
    <input id="lg-email" type="email" placeholder="E-mail" autocomplete="username" required>
    <input id="lg-pass" type="password" placeholder="Mot de passe" autocomplete="current-password" required>
    <button id="lg-in" class="lg-primary">Se connecter</button>
    <button id="lg-up" class="lg-ghost">Première fois : créer mon compte</button>
    <a href="#" id="lg-reset">Mot de passe oublié</a>
    <p class="lg-msg" id="lg-msg" role="status"></p>
  </form>
</div>'''
rep('<div class="sync" id="sync">', '''<details class="reglages"><summary>Réglages</summary>
      <div class="rg">
        <p><b>Clé Gemini</b> · <span id="rg-keystate"></span></p>
        <div class="rg-row"><input id="rg-key" type="password" placeholder="Colle ta clé API Gemini" autocomplete="off"><button id="rg-save" type="button">Enregistrer</button><button id="rg-test" type="button">Tester</button></div>
        <p>Modèle : <span id="rg-model"></span></p>
        <p><label class="rg-imp">Importer un suivi (.json)<input id="rg-import" type="file" accept="application/json,.json" class="vh"></label></p>
        <p>Compte : <span id="rg-user"></span> · <button id="rg-out" type="button" class="rg-link">Se déconnecter</button></p>
        <p class="rg-msg" id="rg-msg" role="status"></p>
      </div>
    </details>
    <div class="sync" id="sync">''')
css = '''
.login{position:fixed;inset:0;z-index:100;background:var(--bg);display:flex;align-items:center;justify-content:center;padding:24px max(16px, env(safe-area-inset-left, 0px))}
.lg-card{width:100%;max-width:360px;display:flex;flex-direction:column;gap:10px;text-align:center}
.lg-logo{display:flex;gap:10px;justify-content:center;margin-bottom:6px}
.lg-logo span{width:18px;height:18px;border-radius:50%;background:var(--miss)}
.lg-logo span:nth-child(2){background:var(--redo)}.lg-logo span:nth-child(3){background:var(--val)}
.lg-card h1{font-family:var(--f-display);font-weight:500;font-size:28px;margin:0}
.lg-sub{color:var(--muted);font-size:14px;margin:0 0 8px}
.lg-card input{font:inherit;font-size:16px;padding:12px 14px;border-radius:12px;border:1px solid var(--line);background:var(--surface);color:var(--fg)}
.lg-primary{font:inherit;font-weight:600;padding:12px;border-radius:12px;border:0;background:var(--fg);color:var(--bg);cursor:pointer}
.lg-ghost{font:inherit;padding:11px;border-radius:12px;border:1px solid var(--line);background:transparent;color:var(--fg);cursor:pointer}
#lg-reset{color:var(--muted);font-size:13px}
.lg-msg{min-height:1.2em;color:var(--miss-fg);font-size:13.5px}
.reglages{margin:24px 0 8px;border-top:1px solid var(--line);padding-top:14px;font-size:13.5px;color:var(--muted)}
.reglages summary{cursor:pointer;color:var(--fg);font-weight:500}
.rg{display:flex;flex-direction:column;gap:6px;margin-top:10px}
.rg p{margin:0}.rg b{color:var(--fg);font-weight:600}
.rg-row{display:flex;flex-wrap:wrap;gap:6px}
.rg-row input{flex:1 1 200px;min-width:0;font:inherit;padding:8px 10px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--fg)}
.rg button,.rg-imp{font:inherit;font-size:13px;padding:7px 12px;border-radius:999px;border:1px solid var(--line);background:var(--surface);color:var(--fg);cursor:pointer;display:inline-block}
.rg .rg-link{padding:0;border:0;background:none;text-decoration:underline;color:var(--muted)}
.rg-msg{color:var(--fg)}
'''
rep('</style>', css + '</style>')

module = '''<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager, memoryLocalCache, collection, doc, setDoc, deleteDoc, onSnapshot, writeBatch } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
const app = initializeApp(__CFG__);
const auth = getAuth(app);
let fs;
try{ fs = initializeFirestore(app, {ignoreUndefinedProperties: true, localCache: persistentLocalCache({tabManager: persistentMultipleTabManager()})}); }
catch(e){ fs = initializeFirestore(app, {ignoreUndefinedProperties: true, localCache: memoryLocalCache()}); }
window.FB = {
  onAuth: cb => onAuthStateChanged(auth, cb),
  signIn: (e, p) => signInWithEmailAndPassword(auth, e, p),
  signUp: (e, p) => createUserWithEmailAndPassword(auth, e, p),
  reset: e => sendPasswordResetEmail(auth, e),
  signOut: () => signOut(auth),
  db(uid){
    return { collection(name){
      const col = collection(fs, "users", uid, name);
      return {
        doc(id){ const r = doc(col, id); return { set: d => setDoc(r, d), delete: () => deleteDoc(r) }; },
        onSnapshot(cb, err){ return onSnapshot(col, {includeMetadataChanges: true}, cb, err); }
      };
    } };
  },
  async batchSet(uid, name, obj){
    const ents = Object.entries(obj); let n = 0;
    for(let i = 0; i < ents.length; i += 400){
      const b = writeBatch(fs);
      ents.slice(i, i + 400).forEach(([id, v]) => { b.set(doc(fs, "users", uid, name, id), v); n++; });
      await b.commit();
    }
    return n;
  }
};
window.dispatchEvent(new Event("fb-ready"));
</script>'''.replace('__CFG__', cfg)

head = '''<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0d0e10">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="400 exos">
<link rel="manifest" href="manifest.json">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="icon" type="image/png" href="icon-192.png">
<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0}[hidden]{display:none!important}img{max-width:100%}</style>
''' + module + '''
</head>
<body>
'''
t = head + t + login_html + '\n</body>\n</html>\n'
open('app/index.html', 'w').write(t)
json.dump({"name": "Suivi 400 exos", "short_name": "400 exos", "start_url": "./", "scope": "./", "display": "standalone",
           "background_color": "#0d0e10", "theme_color": "#0d0e10",
           "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png"}, {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"}]},
          open('app/manifest.json', 'w'), ensure_ascii=False, indent=1)
imp = json.load(open('app/mon-suivi-base.json')) if os.path.exists('app/mon-suivi-base.json') else {}
imp['content'] = content_docs
json.dump(imp, open('app/mon-suivi.json', 'w'), ensure_ascii=False)
print("app/index.html", len(t), "| contenu:", len(CONTENT), "exos,", max(len(d["j"].encode()) for d in content_docs.values()), "octets max/chapitre")
