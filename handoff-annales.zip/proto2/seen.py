"""« Tombé dans » : occurrences du même classique dans les annales, d'après le giga répertoire (thème + notions)."""
import json, re, glob, subprocess
rows = json.load(open('/home/claude/rep/rows.json'))
KW = {
 "suite implicite": r"implicite", "Wallis": r"wallis", "Stirling": r"stirling", "Gamma": r"\bgamma\b|fonction gamma|Γ",
 "constante d'Euler": r"constante d.euler", "comparaison série-intégrale": r"s[ée]rie.{0,3}int[ée]grale|comparaison s[ée]rie",
 "série alternée": r"altern", "séries de Bertrand": r"bertrand", "séries doubles": r"s[ée]ries? doubles?|produit de cauchy",
 "extremum sous contrainte": r"contrainte", "extremum libre": r"extrem|minimum|maximum",
 "fonction définie par une intégrale": r"d[ée]finie par une int[ée]grale|fonction int[ée]grale|int[ée]grales? [àa] param",
 "Taylor": r"taylor", "Cauchy-Schwarz": r"cauchy.?schwarz", "somme de série": r"somme d.une s[ée]rie|calcul de la somme|somme de la s[ée]rie",
 "récurrence linéaire": r"lin[ée]aire d.ordre|r[ée]currente lin[ée]aire", "suite récurrente": r"suite d[ée]finie par (une )?(relation de )?r[ée]currence|suite r[ée]currente",
 "convexité": r"convex", "suite d'intégrales": r"suites? d.int[ée]grales|suite d[ée]finie par une int[ée]grale",
}
def label(r):
    s, raw = r['_src'], str(r['_year']) + ' ' + str(r.get('Année / sujet', ''))
    y = re.search(r'\d{4}', raw).group(0)
    m = re.search(r'20\d\d-(\d)', raw)
    if s == 'EDHEC': c = 'EDHEC'
    elif s == 'emlyon': c = 'emlyon'
    elif s == 'Maths 2': c = 'HEC Maths II'
    elif s.startswith('Maths 1 ESSEC'): c = 'ESSEC Maths I'
    else: c = 'HEC-ESSEC Maths I'
    return c, y + (f' (sujet {m.group(1)})' if m else '')
def text(r): return str(r.get('Thème principal', '')) + ' ' + str(r.get('Notions du programme utilisées', ''))
items = []
for fp in sorted(glob.glob('/home/claude/rep/out/*.js')):
    out = subprocess.run(['node', '-e', f"global.PROTO=[];require({json.dumps(fp)});console.log(JSON.stringify(PROTO.map(x=>({{kind:x.kind,src:x.src,conc:x.conc,year:x.year,tags:x.tags||[]}}))))"], capture_output=True, text=True)
    if out.returncode == 0: items += json.loads(out.stdout)
def slug(s):
    import unicodedata
    s = unicodedata.normalize('NFD', s.lower()); s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return re.sub(r'^-|-$', '', re.sub(r'[^a-z0-9]+', '-', s))
seen, cnt = {}, {}
for x in items:
    base = slug(x['src']) + '-' + x['kind']; cnt[base] = cnt.get(base, 0) + 1
    xid = base + (f"-{cnt[base]}" if cnt[base] > 1 else '')
    own = (x['conc'] if x['conc'] != 'emlyon' else 'emlyon', str(x['year']) + (' (sujet ' + re.search(r'sujet (\d)', x['src']).group(1) + ')' if re.search(r'sujet (\d)', x['src']) else ''))
    occ = [list(own)]
    pats = [KW[t] for t in x['tags'] if t in KW]
    if pats:
        for r in rows:
            if any(re.search(p, text(r), re.I) for p in pats):
                c, y = label(r)
                if c == own[0] and y.split(' ')[0] == str(x['year']): continue
                if [c, y] not in occ: occ.append([c, y])
    occ = occ[:1] + sorted(occ[1:], key=lambda o: -int(o[1][:4]))[:9]
    seen[xid] = occ
json.dump(seen, open('/home/claude/proto2/seen.json', 'w'), ensure_ascii=False, indent=0)
for k, v in seen.items(): print(k, v)
