t = open('app.tpl.html').read()
def rep(a, b):
    global t
    assert t.count(a) == 1, a[:60]; t = t.replace(a, b)
rep('<a href="#carnet" data-tab="carnet">Carnet<span class="c" id="c-cn"></span></a>',
    '<a href="#carnet" data-tab="carnet">Carnet<span class="c" id="c-cn"></span></a>\n    <a href="#atelier" data-tab="atelier">Atelier</a>')
rep('if(tab === "ex") renderEx(); else if(tab === "pb") renderPb(); else renderCarnet();',
    'if(tab === "ex") renderEx(); else if(tab === "pb") renderPb(); else if(tab === "atelier") renderAtelier(); else renderCarnet();')
rep('tab = h === "pb" ? "pb" : h === "carnet" ? "carnet" : "ex";', 'tab = h === "pb" ? "pb" : h === "carnet" ? "carnet" : h === "atelier" ? "atelier" : "ex";')
# ajout dynamique d'un élément
rep('const EXS = ITEMS.filter(x => x.kind === "ex"), PBS = ITEMS.filter(x => x.kind === "pb");',
'''const EXS = ITEMS.filter(x => x.kind === "ex"), PBS = ITEMS.filter(x => x.kind === "pb");
function addItem(x){
  if(BY[x.id]) return;
  x.qs = x.qs || []; x.qs.forEach(q => { q.imp = q.imp || 2; q.min = q.min || 5; q.deps = q.deps || []; });
  x.seen = x.seen || []; x.custom = true; ITEMS.push(x); BY[x.id] = x; (x.kind === "pb" ? PBS : EXS).push(x);
}''')
atelier = r'''
/* ---------- Atelier : transcrire un sujet avec Gemini ---------- */
const TODO = [
 ["EDHEC",2018,"ex",10,1,"Sujet 1, Ex. 1 (suite implicite)"],["EDHEC",2018,"ex",11,2,"Sujet 3, Ex. 1"],["EDHEC",2026,"ex",9,2,"Ex. 2 (DL, trigonométrie)"],
 ["EDHEC",1995,"pb",0,1,"Problème (rectangles)"],["EDHEC",2021,"pb",0,1,"Problème I(p,q)"],["EDHEC",1993,"pb",0,2,"Problème"],["EDHEC",2012,"pb",0,2,"Problème (Carleman)"],["EDHEC",2018,"pb",0,2,"Sujet 1 (Wallis + VA)"],["EDHEC",2022,"pb",0,2,"Problème (sh/ch)"],["EDHEC",2024,"pb",0,2,"Problème"],["EDHEC",2025,"pb",0,2,"Problème (Catalan)"],["EDHEC",2023,"pb",0,3,"Problème (n-périodiques)"],
 ["emlyon",2004,"pb",0,1,"Problème 1 (Dirichlet/Laplace)"],["emlyon",2011,"ex",13,1,"Exercice Stirling"],["emlyon",2013,"pb",0,1,"Problème 1"],["emlyon",2024,"pb",0,1,"Problème 2 (Gamma/Stirling)"],["emlyon",1991,"pb",0,2,"Problème 2"],["emlyon",1996,"pb",0,2,"Problème 2"],["emlyon",1997,"pb",0,2,"Problème 2"],["emlyon",1999,"pb",0,2,"Problème 2"],["emlyon",2006,"pb",0,2,"Problème 1"],["emlyon",2007,"pb",0,2,"Problème 1"],["emlyon",2011,"ex",14,2,"Exercice extremum"],["emlyon",2016,"pb",0,2,"Problème 2 (η)"],["emlyon",2017,"pb",0,2,"Problème 2"],["emlyon",2020,"pb",0,2,"Problème 1"],["emlyon",1990,"pb",0,3,"Problème 2"],["emlyon",1993,"pb",0,3,"Problème 2"],["emlyon",1995,"pb",0,3,"Problème 2"],["emlyon",2009,"pb",0,3,"Problème 1"],["emlyon",2015,"pb",0,3,"Problème 2 (Laplace)"],["emlyon",2018,"pb",0,3,"Problème 1"],["emlyon",2022,"pb",0,3,"Problème 2"],
 ["ESSEC Maths I",2001,"pb",0,1,"ζ(2)"],["ESSEC Maths I",1994,"pb",0,2,"Gamma à 2 paramètres"],["ESSEC Maths I",2005,"pb",0,2,"Legendre-Fenchel"],["ESSEC Maths I",2013,"pb",0,2,"Problème"],["ESSEC Maths I",2016,"pb",0,2,"Problème"],["ESSEC Maths I",1993,"pb",0,3,"π"],
 ["HEC-ESSEC Maths I",2026,"pb",0,2,"S-convexes"],["HEC-ESSEC Maths I",2023,"pb",0,3,"Stieltjes / Hausdorff"],
 ["HEC Maths I",1991,"pb",0,2,"Gamma"],["HEC Maths I",1994,"pb",0,2,"ln n!"],["HEC Maths I",1997,"pb",0,2,"Concavité"],["HEC Maths I",2000,"pb",0,2,"Optimisation sous contrainte"],["HEC Maths I",2005,"pb",0,2,"Γ, digamma"],["HEC Maths I",2008,"pb",0,2,"Minimum à n variables"],["HEC Maths I",2009,"pb",0,2,"Suites récurrentes linéaires"],["HEC Maths I",1984,"pb",0,3,"Gamma"],["HEC Maths I",1989,"pb",0,3,"ζ(2k), Bernoulli"],["HEC Maths I",2002,"pb",0,3,"Minimax"],
 ["ESCP",1986,"pb",0,2,"Suite somme"],["ESCP",1994,"pb",0,2,"Wallis"],["ESCP",1993,"pb",0,3,"Involutions"],["ESCP",1995,"pb",0,3,"ζ"],["ESCP",2002,"pb",0,3,"Quadrature de Gauss"],
 ["ESC",1998,"ex",0,2,"Ex. 2"],["ESC",1999,"ex",0,2,"Ex. 2"],["ESC",2000,"ex",0,2,"Ex. 1"],["ESC",2001,"ex",0,2,"Ex. 3"],["ESC",2002,"ex",0,2,"Ex. 3"],["ESC",2003,"ex",0,2,"Ex. 1"],["ESC",2006,"ex",0,2,"Ex. 1"],["ESC",2006,"ex",0,2,"Ex. 2"],
 ["Oral ESCP/HEC",0,"ex",9,2,"Asymptote oblique par DL"],["Oral ESCP/HEC",0,"ex",9,2,"Théorème de la moyenne / d'Alembert / propriété du roi"]
];
const ATL = {pick: null, busy: false, res: null, files: {s: [], c: []}};
const ATL_PROMPT = `Tu transcris un exercice ou problème d'annale officiel de mathématiques (prépa ECG, concours BCE) pour une application de révision.
RÈGLES : énoncé MOT POUR MOT (mêmes notations, même numérotation 1., 2.a)…), rien d'ajouté, rien de résumé. Supprime les questions d'informatique (Python/Scilab/Pascal) sans renuméroter.
FORMAT : HTML simple (<p>, <ol><li>, <ol type="a">, <b>, <br>), maths en LaTeX avec $…$ et $$…$$ ; écris \\lt et \\gt au lieu de < et > dans les formules ; jamais d'accent grave ; coupe les longues égalités avec \\begin{aligned}…\\end{aligned}.`;
async function atlRun(){
  const st = $("#atl-msg"), want = x => (ATL.files[x] || []);
  const meta = {conc: $("#atl-conc").value.trim(), year: +$("#atl-year").value || 0, src: $("#atl-src").value.trim(), kind: $("#atl-kind").value, ch: +$("#atl-ch").value, lvl: +$("#atl-lvl").value, part: $("#atl-part").value.trim()};
  if(!want("s").length){ st.textContent = "Ajoute au moins le sujet (PDF ou photos)."; return; }
  if(!meta.src){ st.textContent = "Renseigne la source (ex. EDHEC 2018 (sujet 1))."; return; }
  ATL.busy = true; $("#atl-go").disabled = true;
  try{
    st.textContent = "1/2 · Gemini lit le sujet… (jusqu'à 2 minutes)";
    const A = await sampleFn.json(`${ATL_PROMPT}
Voici le sujet${meta.part ? " (ne transcris que : " + meta.part + ")" : ""}. Produis UNIQUEMENT ce JSON :
{"t": "titre court qui dit le classique (peut contenir $…$)", "dur": minutes réalistes pour un bon candidat (exercice EDHEC 45-60, problème 100-240), "tags": [parmi : suite implicite, suite récurrente, suites adjacentes, suite d'intégrales, équivalents, développement limité, Taylor, accroissements finis, convexité, fonction réciproque, fonction définie par une intégrale, intégration par parties, changement de variable, Wallis, Stirling, Gamma, Gauss, constante d'Euler, comparaison série-intégrale, série alternée, séries de Riemann, séries de Bertrand, somme de série, séries doubles, intégrale impropre, extremum libre, extremum sous contrainte, Cauchy-Schwarz, hessienne, récurrence linéaire, probabilités, convergence en loi],
"qs": [{"id": "1a", "label": "3 à 8 mots qui disent ce qu'on fait", "imp": 1 pour une question classique à savoir refaire (≈20-30 % des questions dans un problème), 2 standard, 3 calcul/vérification, "min": minutes, "deps": ["1a"] facultatif si elle utilise directement un résultat précédent}] (TOUTES les questions numérotées, dans l'ordre),
"e": "énoncé complet en HTML"}`, {images: want("s"), modelTier: "complex", maxTokens: 60000});
    st.textContent = "2/2 · Gemini lit le corrigé…";
    const C = await sampleFn.json(`${ATL_PROMPT}
Voici l'énoncé transcrit :
${A.e}
${want("c").length ? "Les fichiers joints sont le CORRIGÉ publié. Transcris-le fidèlement (mêmes arguments, mêmes calculs) ; tu peux corriger une coquille évidente et compléter un « on voit facilement » par la justification standard ; si tu détectes une erreur mathématique, corrige-la et ajoute en fin de question <p class=\\"note\\">Note : …</p>." : "Aucun corrigé n'est fourni : rédige toi-même un corrigé complet et rigoureux, au niveau de rédaction exigé au concours (chaque calcul vérifié)."}
Structure en <ol> qui suit exactement la numérotation de l'énoncé. Produis UNIQUEMENT ce JSON : {"c": "corrigé complet en HTML"}`, {images: want("c"), modelTier: "complex", maxTokens: 60000});
    const fixm = s => String(s || "").replace(/\$\$[\s\S]*?\$\$|\$[^$\n]*\$/g, m => m.replace(/</g, "\\lt ").replace(/>/g, "\\gt ")).replace(/`/g, "");
    ATL.res = {kind: meta.kind, ch: meta.kind === "pb" ? 0 : meta.ch, t: A.t || meta.src, conc: meta.conc, year: meta.year, src: meta.src,
      corr: want("c").length ? "Corrigé publié (transcrit par Gemini)" : "Corrigé rédigé par Gemini (aucun corrigé publié)", dur: A.dur || 60, lvl: meta.lvl, tags: A.tags || [],
      qs: (A.qs || []).map(q => ({...q, id: String(q.id)})), e: fixm(A.e), c: fixm(C.c)};
    st.textContent = ""; atlPreview();
  }catch(err){ st.textContent = ckErr[err?.code] || ("Échec (" + (err?.code || "erreur") + ")."); }
  ATL.busy = false; $("#atl-go").disabled = false;
}
function atlPreview(){
  const r = ATL.res, box = $("#atl-prev"); if(!r){ box.innerHTML = ""; return; }
  box.innerHTML = `<section class="card"><div class="src">Aperçu · ${esc(r.src)} · ${r.qs.length} questions · ${r.dur} min</div><h3 style="margin:6px 0">${esc(r.t)}</h3><div>${r.e}</div><details style="margin-top:12px"><summary><b>Corrigé</b></summary><div>${r.c}</div></details>
    <p class="intro">Relis l'énoncé en regard du sujet original. Si une formule est cassée, retranscris (« Transcrire » refait un essai) plutôt que d'ajouter.</p>
    <div class="row-btns"><button class="btn-ink" id="atl-add">Ajouter à ma banque</button><button class="btn-line" id="atl-drop">Rejeter</button></div></section>`;
  tex(box);
}
async function atlAdd(){
  const r = ATL.res; if(!r) return;
  const base = slug(r.src) + "-" + r.kind; let id = base, n = 1; while(BY[id]) id = base + "-" + (++n);
  r.id = id; addItem(r);
  if(db) db.collection("custom2").doc(id).set({j: JSON.stringify(r)}).catch(() => { $("#sync").textContent = "Enregistrement impossible, réessaie"; });
  const key = [r.conc, r.year, r.kind, r.src].join("|"); SET.atl = {...(SET.atl || {}), [ATL.pick || key]: id}; save("settings", "main", SET);
  ATL.res = null; ATL.pick = null; render();
}
function renderAtelier(){
  const m = $("#main"), done = SET.atl || {};
  const grp = {}; TODO.forEach((x, i) => (grp[x[0]] = grp[x[0]] || []).push([x, i]));
  const sel = (id, opts, v) => `<select id="${id}">${opts.map(([a, b]) => `<option value="${a}"${a == v ? " selected" : ""}>${b}</option>`).join("")}</select>`;
  const p = ATL.pick != null ? TODO[ATL.pick.split(":")[1]] : null;
  m.innerHTML = `<section class="head"><div class="eyebrow">Atelier</div><h1 style="font-size:34px">Ajouter un sujet à ta banque</h1></section>
  <p class="intro">Gemini (gratuit) retranscrit un sujet : tu déposes le PDF du sujet et celui du corrigé (Major Prépa), il produit l'énoncé, les questions et le corrigé. Tu relis l'aperçu, tu valides, et l'élément rejoint ta banque. Aucun coût Claude.</p>
  <section class="card"><div class="src">1 · Choisis un sujet de la liste (ou saisis le tien)</div>
  ${Object.entries(grp).map(([c, l]) => `<details><summary><b>${esc(c)}</b> · ${l.filter(([x, i]) => done["t:" + i]).length}/${l.length} faits</summary><div style="display:flex;flex-direction:column;gap:4px;margin:6px 0 10px">${l.map(([x, i]) => `<button class="btn-line" style="text-align:left${done["t:" + i] ? ";opacity:.5" : ""}" data-pick="${i}">${done["t:" + i] ? "✓ " : ""}${["", "🟡", "🟢", "🔵"][x[4]]} ${x[1] || ""} · ${esc(x[5])}</button>`).join("")}</div></details>`).join("")}</section>
  <section class="card"><div class="src">2 · Fichiers et réglages</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin:8px 0">
   <input id="atl-conc" placeholder="Concours" value="${p ? esc(p[0]) : ""}"><input id="atl-year" placeholder="Année" value="${p && p[1] ? p[1] : ""}"><input id="atl-src" placeholder="Source (ex. EDHEC 2018 (sujet 1))" value="${p ? esc(p[0] + " " + (p[1] || "")).trim() : ""}">
   ${sel("atl-kind", [["ex", "Exercice"], ["pb", "Problème"]], p ? p[2] : "ex")}${sel("atl-ch", Object.entries(CH).map(([k, v]) => [k, k + " · " + v]), p && p[3] ? p[3] : 10)}${sel("atl-lvl", [[1, "🟡 Indispensable"], [2, "🟢 Très important"], [3, "🔵 Important"]], p ? p[4] : 2)}
  </div>
  <input id="atl-part" style="width:100%;box-sizing:border-box;margin-bottom:8px" placeholder="Partie à transcrire (ex. « Exercice 2 seulement », « Problème 1 »)" value="${p ? esc(p[5]) : ""}">
  <div class="row-btns"><label class="btn-line" style="cursor:pointer">Sujet (PDF / photos)<input type="file" accept="application/pdf,image/*" multiple id="atl-fs" hidden></label><label class="btn-line" style="cursor:pointer">Corrigé (PDF / photos)<input type="file" accept="application/pdf,image/*" multiple id="atl-fc" hidden></label><span id="atl-files" class="status-msg">${ATL.files.s.length} fichier(s) sujet · ${ATL.files.c.length} corrigé</span></div>
  <div class="row-btns" style="margin-top:10px"><button class="btn-ink" id="atl-go">Transcrire avec Gemini</button><span class="status-msg" id="atl-msg"></span></div></section>
  <div id="atl-prev"></div>`;
  atlPreview();
}
document.addEventListener("click", e => {
  const b = e.target.closest("[data-pick]"); if(b && tab === "atelier"){ ATL.pick = "t:" + b.dataset.pick; ATL.res = null; renderAtelier(); window.scrollTo(0, document.querySelector("#atl-conc").getBoundingClientRect().top + scrollY - 120); return; }
  if(e.target.id === "atl-go" && !ATL.busy) atlRun();
  if(e.target.id === "atl-add") atlAdd();
  if(e.target.id === "atl-drop"){ ATL.res = null; atlPreview(); }
});
document.addEventListener("change", e => {
  const id = e.target.id; if(id !== "atl-fs" && id !== "atl-fc") return;
  ATL.files[id === "atl-fs" ? "s" : "c"] = [...e.target.files];
  $("#atl-files").textContent = ATL.files.s.length + " fichier(s) sujet · " + ATL.files.c.length + " corrigé";
});
'''
rep('/* ---------- Routage ---------- */', atelier + '\n/* ---------- Routage ---------- */')
# chargement des éléments ajoutés
rep('  db.collection("carnet2").onSnapshot(', '  db.collection("custom2").onSnapshot(snap => { snap.docs.forEach(d => { try{ const x = JSON.parse(d.data().j); x.id = d.id; addItem(x); }catch(e){} }); rerender(); }, () => {});\n  db.collection("carnet2").onSnapshot(')
rep('Analyse · prototype v2', 'Analyse')
open('app.tpl.html', 'w').write(t)
