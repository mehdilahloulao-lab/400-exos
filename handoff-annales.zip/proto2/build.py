import re, json, glob, base64, subprocess, sys
T = open('/home/claude/proto2/app.tpl.html').read()

def fixmath(s):
    # dans les maths : < > → \lt \gt
    def f(m):
        x = m.group(0)
        return x.replace('<', r'\lt ').replace('>', r'\gt ')
    return re.sub(r'\$\$.+?\$\$|\$[^$]+?\$', f, s, flags=re.S)

files = sorted(glob.glob('/home/claude/rep/out/*.js'))
data = []
for fp in files:
    src = open(fp).read()
    ok = subprocess.run(['node', '-e', f"global.PROTO=[];require({json.dumps(fp)});"], capture_output=True, text=True)
    if ok.returncode:
        print('REJET', fp, ok.stderr[:300]); continue
    data.append(fixmath(src))
T = T.replace('/*__DATA__*/', '\n'.join(data))
seen = json.load(open('/home/claude/proto2/seen.json')) if glob.glob('/home/claude/proto2/seen.json') else {}
T = T.replace('/*__SEEN__*/{}', json.dumps(seen, ensure_ascii=False))
for k, f in [('R', 'cmu-500-roman'), ('I', 'cmu-500-italic'), ('B', 'cmu-700-roman')]:
    T = T.replace(f'__CMU_{k}__', base64.b64encode(open(f'/home/claude/fonts/{f}.woff2', 'rb').read()).decode())
open('/home/claude/proto2/classiques-v2.html', 'w').write(T)
print('ok', len(files), 'fichiers', len(T) // 1024, 'Ko')
