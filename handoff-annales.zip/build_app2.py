# App v2 indépendante (GitHub Pages + Firebase + Gemini) à partir de proto2/classiques-v2.html
# Le code et la liste des sujets sont publics ; énoncés et corrigés vont dans TA base Firebase (collection "content2"), via import.
import json, re, os, shutil, subprocess, tempfile
B = open('/home/claude/build_app.py').read()
cfg = open('app/firebase-config.json').read().strip()
def grab(var):  # récupère une chaîne r'''...''' ou '''...''' définie dans build_app.py
    m = re.search(var + r" = r?'''(.*?)'''", B, re.S); return m.group(1)
app_js, login_html, css = grab('app_js'), grab('login_html'), grab('css')
module = grab('module').replace('__CFG__', cfg)
module = '<script type="module">' + module.split('<script type="module">', 1)[-1] if '<script type="module">' in module else module
module = module if module.strip().startswith('<script') else '<script type="module">' + module
if not module.rstrip().endswith('</script>'): module += '</script>'

t = open('/home/claude/proto2/classiques-v2.html').read()
def rep(old, new, cnt=1):
    global t
    assert t.count(old) == cnt, ("COUNT", t.count(old), old[:80]); t = t.replace(old, new)

# ---- contenu : on sort e / c du code public ----
i0 = t.index('const PROTO = [];'); i1 = t.index('const SEEN =')
seg = t[i0:i1]
tf = tempfile.NamedTemporaryFile('w', suffix='.js', delete=False)
tf.write(seg.replace('const PROTO = [];', 'global.PROTO = [];') + '\nprocess.stdout.write(JSON.stringify(PROTO));'); tf.close()
P = json.loads(subprocess.run(['node', tf.name], capture_output=True, text=True, check=True).stdout)
def slug(s):
    import unicodedata
    s = unicodedata.normalize('NFD', s.lower()); s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return re.sub(r'^-|-$', '', re.sub(r'[^a-z0-9]+', '-', s))
cnt, content = {}, {}
for x in P:
    base = slug(x['src']) + '-' + x['kind']; cnt[base] = cnt.get(base, 0) + 1
    xid = base + (f"-{cnt[base]}" if cnt[base] > 1 else '')
    content[xid] = {"j": json.dumps({"e": x.pop('e', ''), "c": x.pop('c', '')}, ensure_ascii=False)}
t = t[:i0] + 'const PROTO = ' + json.dumps(P, ensure_ascii=False) + ';\n' + t[i1:]

# ---- base : Firebase ; IA : Gemini ----
rep('''  try{ sampleFn = window.claude?.use ? await window.claude.use("sample") : null; }catch(e){ sampleFn = null; }
  try{ db = window.claude?.use ? await window.claude.use("db") : null; }catch(e){ db = null; }''',
    '''  sampleFn = GEM;
  try{ db = await appLogin(); }catch(e){ db = null; }''')
rep('''<span class="status-msg" id="gradeMsg"></span>''', '''<span class="status-msg" id="gradeMsg"></span>''')
rep('''catch(err){ $("#gradeMsg").textContent = err?.code === "rate_limited" ? "Trop de demandes, réessaie dans un moment." : "La correction a échoué."; $("#gradeBtn").disabled = false; }''',
    '''catch(err){ $("#gradeMsg").textContent = ckErr[err?.code] || (err?.code === "rate_limited" ? "Trop de demandes, réessaie dans un moment." : "La correction a échoué (" + (err?.code || "erreur") + ")."); $("#gradeBtn").disabled = false; }''')
rep('if(!sampleFn){ $("#gradeMsg").textContent = "Correction indisponible ici."; return; }',
    'if(!sampleFn){ $("#gradeMsg").textContent = "Correction indisponible ici."; return; }\n  if(!x.e){ $("#gradeMsg").textContent = "Énoncé pas encore importé (Réglages, en bas de page)."; return; }')
rep('Énoncé en cours de retranscription.', 'Énoncé absent : importe contenu-analyse.json dans Réglages, en bas de la page d’accueil.')

# adaptation du bloc app_js de la v1
js = app_js
js = js.replace('''  store.collection("content").onSnapshot(snap => {
    snap.docs.forEach(d => { const v = d.data(); if(v && v.j){ try{ Object.assign(CONTENT, JSON.parse(v.j)); }catch(e){} } });
    const empty = !Object.keys(CONTENT).length; $("#rg-msg").textContent = empty ? "Énoncés et corrigés absents : importe le fichier mon-suivi.json dans Réglages." : $("#rg-msg").textContent;
    if(empty){ const r = document.querySelector(".reglages"); if(r) r.open = true; }
    if(openId) openSheet(openId);
  }, () => {});''', '''  store.collection("content2").onSnapshot(snap => {
    let n = 0;
    snap.docs.forEach(d => { const v = d.data(); const x = BY[d.id]; if(x && v && v.j){ try{ const o = JSON.parse(v.j); x.e = o.e; x.c = o.c; (x.parts || []).forEach(q => { q.e = o.e; q.c = o.c; }); n++; }catch(e){} } });
    const empty = !snap.docs.length; const r = document.querySelector(".reglages");
    if(empty && !snap.metadata.fromCache){ $("#rg-msg").textContent = "Énoncés et corrigés absents : importe contenu-analyse.json ici."; if(r) r.open = true; }
    if(cur && cur.e && !document.querySelector("#sol")?.textContent.trim().length) openItem(cur.id);
    else if(cur && cur.e && /Énoncé absent/.test($("#main").textContent)) openItem(cur.id);
  }, () => {});''')
assert 'content2' in js
js = js.replace('$("#rg-msg")', 'rgMsg()')
js = 'const rgMsg = () => document.getElementById("rg-msg") || {set textContent(v){}};\n' + js
js = js.replace('generationConfig: {responseMimeType: "application/json", temperature: 0.2}', 'generationConfig: {responseMimeType: "application/json", temperature: 0.2, maxOutputTokens: opts.maxTokens || 8192}')
assert 'opts.maxTokens' in js
js = js.replace('const GEM = async () => ({text: ""});', '''const GEM = async () => ({text: ""});
const ckErr = {no_key: "Ajoute ta clé Gemini dans Réglages (en bas de la page d'accueil).", bad_key: "Clé Gemini refusée : vérifie-la dans Réglages.", overloaded: "Gemini est surchargé : réessaie dans une minute.", network: "Pas de connexion internet.", refused: "Gemini a refusé la demande.", invalid_json: "Réponse illisible de Gemini : réessaie.", empty_completion: "Réponse vide de Gemini : réessaie."};''')
rep('/* ---------- Stockage ---------- */', js + '\n/* ---------- Stockage ---------- */')

settings = '''<footer class="wrap foot"><details class="reglages"><summary>Réglages</summary>
      <div class="rg">
        <p><b>Clé Gemini</b> · <span id="rg-keystate"></span></p>
        <div class="rg-row"><input id="rg-key" type="password" placeholder="Colle ta clé API Gemini" autocomplete="off"><button id="rg-save" type="button">Enregistrer</button><button id="rg-test" type="button">Tester</button></div>
        <p>Modèle : <span id="rg-model"></span></p>
        <p><label class="rg-imp">Importer énoncés et corrigés (.json)<input id="rg-import" type="file" accept="application/json,.json" class="vh" hidden></label></p>
        <p>Compte : <span id="rg-user"></span> · <button id="rg-out" type="button" class="rg-link">Se déconnecter</button></p>
        <p class="rg-msg" id="rg-msg" role="status"></p>
      </div>
    </details></footer>
<p class="sync" id="sync"></p>'''
rep('<p class="sync" id="sync"></p>', settings)
rep('</style>', css + '.foot{margin-top:40px}\n</style>')
login = login_html.replace('<h1>Suivi 400 exos</h1>', "<h1>Classiques d'annales</h1>")
head = '''<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0d0e10">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Annales">
<link rel="manifest" href="manifest.json">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="icon" type="image/png" href="icon-192.png">
<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0}[hidden]{display:none!important}img{max-width:100%}</style>
''' + module + '''
</head>
<body>
'''
t = head + t + login + '\n</body>\n</html>\n'
os.makedirs('app2', exist_ok=True)
open('app2/index.html', 'w').write(t)
for f in ['apple-touch-icon.png', 'icon-192.png', 'icon-512.png']: shutil.copy('app/' + f, 'app2/' + f)
json.dump({"name": "Classiques d'annales", "short_name": "Annales", "start_url": "./", "scope": "./", "display": "standalone",
           "background_color": "#0d0e10", "theme_color": "#0d0e10",
           "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png"}, {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"}]},
          open('app2/manifest.json', 'w'), ensure_ascii=False, indent=1)
json.dump({"content2": content}, open('app2/contenu-analyse.json', 'w'), ensure_ascii=False)
print('app2/index.html', len(t) // 1024, 'Ko |', len(P), 'éléments | contenu', os.path.getsize('app2/contenu-analyse.json') // 1024, 'Ko')
