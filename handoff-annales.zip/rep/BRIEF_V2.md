# Mission : retranscrire des exercices / problèmes d'annales OFFICIELS (maths approfondies, analyse)

Tu travailles pour une application de révision (prépa ECG, concours BCE). Tu retranscris, à partir des PDF
officiels déjà téléchargés, l'ÉNONCÉ EXACT et le CORRIGÉ (proposition de corrigé publiée par Major Prépa /
professeurs) de chaque élément qui t'est assigné, au format JavaScript décrit plus bas.

## Où sont les fichiers
- Sujets : /home/claude/rep/suj/  (ex. `EDHEC-2005-Enonce.pdf`, `maths_emlyon_2010_S_sujet.pdf`, `Sujet-Maths-S-emlyon-2021.pdf`,
  `edhec_2016_s_scan.pdf`, `Maths_edhec_2018_1_S_sujet.pdf` …). Beaucoup sont des SCANS (pas de texte) : il faut les LIRE EN IMAGE.
- Corrigés : /home/claude/rep/pdf/ et aussi /home/claude/rep/suj/ (ex. `Correction_Maths_EDHEC_S_2005.pdf`,
  `correction_maths_emlyon_2010_S.pdf`, `EML-2021-S-corrigé-Major-Prepa.pdf`, `Maths_Edhec_1998_S_correction.pdf`, `2016_edhec-corrige.pdf` …).
  Utilise `ls /home/claude/rep/pdf /home/claude/rep/suj | grep -i <année>` pour trouver les bons fichiers.
- Pour lire un PDF : outil Read avec `pages` (max 20 pages), ou `pdftotext -layout -f N -l M fichier -` (texte, mais les
  fractions/indices sont souvent cassés : vérifie toujours sur l'image), ou `pdftoppm -png -r 110 -f N -l M fichier /tmp/claude-0/-home-claude/a5a80eb8-29d5-5876-86cd-48f25bf750a9/scratchpad/<toi>/p` puis Read du PNG.
- Si le sujet officiel est introuvable mais que le corrigé reproduit l'énoncé (fréquent chez Major Prépa / J.-F. Cossutta),
  reprends l'énoncé depuis le corrigé. Si un énoncé est vraiment introuvable, signale-le dans ton rapport et passe.

## Exigence de fidélité (TRÈS IMPORTANT)
- ÉNONCÉ : mot pour mot, mêmes notations, même numérotation (1., 2.a), …). Ne résume pas, n'ajoute rien.
- CORRIGÉ : fidèle au corrigé publié (mêmes arguments, mêmes calculs). Tu peux : corriger une coquille évidente,
  compléter un « on voit facilement » par la justification standard d'une ligne, remettre en forme. Tu ne réécris pas
  la démarche. Si tu détectes une ERREUR mathématique dans le corrigé, corrige-la et ajoute à la fin de la question
  `<p class="note">Note : …</p>` qui explique la correction.
- Les questions Python / Scilab / Pascal : SUPPRIME-les de l'énoncé et du corrigé (ne renumérote pas ; écris
  `<li value="3">` pour conserver la numérotation si besoin, ou garde le numéro dans le texte).
- Fonctions trigonométriques : garde-les si le sujet les utilise.

## Format de sortie
Un fichier JS : `/home/claude/rep/out/<ton-nom>.js`, contenant UNIQUEMENT :
```js
PROTO.push(
{kind: "ex", ch: 10, t: String.raw`Titre court et parlant (peut contenir $...$)`,
 conc: "EDHEC", year: 2002, src: "EDHEC 2002", corr: "Corrigé Major Prépa (J.-F. Cossutta)",
 dur: 45, lvl: 1, tags: ["suite implicite", "équivalents"],
 qs: [{id: "1", label: String.raw`Existence et unicité de $u_n$`, imp: 2, min: 8}, ...],
 e: String.raw`<p>…énoncé…</p><ol><li>…</li></ol>`,
 c: String.raw`<ol><li>…corrigé…</li></ol>`},
{ ... }
);
```
Champs :
- `kind` : "ex" (exercice) ou "pb" (problème complet).
- `ch` : chapitre (exercices) : 9 Fonctions d'une variable réelle (Taylor, AF, convexité, réciproques) · 10 Suites ·
  11 Intégration sur un segment · 12 Séries · 13 Intégrales généralisées · 14 Fonctions de plusieurs variables.
  Pour un problème : `ch: 0`.
- `t` : titre court qui dit le classique (ex. `Suite implicite $x^n+nx-1=0$ : limite et équivalent`).
- `conc`, `year`, `src` (« EDHEC 2002 », « emlyon 2010 », « EDHEC 2018 (sujet 3) »), `corr` (auteur du corrigé si indiqué).
- `dur` : durée réaliste en minutes pour un bon candidat (EDHEC : ~45-60 min par exercice ; problème emlyon : 100-120 min ;
  base-toi sur la longueur réelle).
- `lvl` : 1 = indispensable (classique qui tombe partout / doit être parfaitement su), 2 = très important, 3 = important.
- `tags` : choisis UNIQUEMENT dans : "suite implicite", "suite récurrente", "suites adjacentes", "suite d'intégrales",
  "équivalents", "développement limité", "Taylor", "accroissements finis", "convexité", "fonction réciproque",
  "fonction définie par une intégrale", "intégration par parties", "changement de variable", "Wallis", "Stirling",
  "Gamma", "Gauss", "constante d'Euler", "comparaison série-intégrale", "série alternée", "séries de Riemann",
  "séries de Bertrand", "somme de série", "séries doubles", "intégrale impropre", "extremum libre",
  "extremum sous contrainte", "Cauchy-Schwarz", "hessienne", "récurrence linéaire", "probabilités", "convergence en loi".
- `qs` : la liste de TOUTES les questions numérotées (sous-questions incluses : "1a", "1b", "2", "3c"…), dans l'ordre :
  `label` = 3 à 8 mots qui disent ce qu'on fait, `imp` = 1 (question classique à savoir refaire / clé du sujet),
  2 (standard), 3 (calcul ou vérification), `min` = minutes estimées. La somme des `min` ≈ `dur`.
- `e` / `c` : HTML simple (`<p>`, `<ol><li>`, `<ol type="a">`, `<b>`, `<br>`), maths en LaTeX MathJax (`$…$`, `$$…$$`,
  `\begin{pmatrix}`, `\begin{aligned}`…). Dans le corrigé, structure en `<ol>` qui suit exactement la numérotation de l'énoncé.
  Les longues égalités : coupe-les avec `\begin{aligned}…\end{aligned}` (lignes de moins de ~70 caractères).

## Règles techniques (sinon le fichier est rejeté)
- JAMAIS d'accent grave (backtick) dans le contenu, JAMAIS la séquence dollar+accolade `${` (écris `$ {` si besoin).
- Utilise `\lt` et `\gt` au lieu de `<` et `>` DANS les formules.
- Vérifie ton fichier : `node -e "global.PROTO=[];require('/home/claude/rep/out/<ton-nom>.js');console.log(PROTO.length)"`.

## Rapport final (court)
Liste des éléments faits (src, titre, nb de questions), éléments manquants et pourquoi, erreurs corrigées dans les corrigés.

## Complément
- Pour un problème (`kind:"pb"`), `imp:1` marque les questions PRIORITAIRES (classiques à savoir refaire) : sois sélectif (≈ 20-30 % des questions).
- Ajoute `deps` facultatif dans `qs` : `deps:["2a"]` si la question utilise directement le résultat d'une question précédente non admis dans l'énoncé (n'en mets que les plus nettes).
- Ne lis pas les rapports du jury. Travaille dans ton propre dossier de brouillon /tmp/claude-0/-home-claude/a5a80eb8-29d5-5876-86cd-48f25bf750a9/scratchpad/<ton-nom>/.

## Compléments (vague 2 — 19/11)
- Sources supplémentaires :
  - `/home/claude/rep/mp_links.tsv` : liens Major Prépa (sujets/corrigés appro 2009-2026). Téléchargement : `curl -sSL -o <fichier> <url>` (major-prepa.com est autorisé). Pour les années absentes, cherche sur major-prepa.com (WebSearch/WebFetch) la page « toutes les annales … » du concours.
  - `/mnt/user-data/uploads/Annales_tout_concours___corrigés.pdf` (M. Vienney, 1194 p., sujets + corrigés : EML p.263-472, EDHEC p.473-734, Maths II p.735-926, ESSEC p.927-1056, HEC p.1057-1160, ESCP p.1161-1174, ESC p.1175-1194). Texte extractible mais symboles grecs/quantificateurs souvent perdus : vérifie sur l'image. ATTENTION : Vienney renumérote parfois les questions (« la numérotation n'est pas celle du sujet original ») : suis la numérotation du sujet officiel si tu l'as, sinon celle de Vienney en le signalant.
  - `/mnt/user-data/attachments/a5a80eb8-29d5-5876-86cd-48f25bf750a9/166f4da4-Oraux_corrig_s_de_ESCP___HEC.pdf` (oraux ESCP/HEC corrigés, texte extractible : `pdftotext`).
- Si AUCUN corrigé n'est publié (ex. sujets 2026), rédige le corrigé toi-même et mets `corr: "Corrigé rédigé (aucun corrigé publié)"` ; vérifie chaque calcul.
- Exercices d'oral : `kind:"ex"`, `conc:"Oral ESCP"` ou `"Oral HEC"`, `src:"Oral ESCP 2016"` (année si connue), corrigé = celui du PDF (complété s'il est lacunaire, en le signalant).
- Sujets de 4 h (HEC, ESSEC, ESCP) : retranscris le problème EN ENTIER ; `imp:1` seulement sur les questions vraiment classiques (≈ 20 %).
- Travaille vite et économe : lis en texte quand c'est possible, en image (110 dpi) seulement ce qui est illisible.

## Ajouts v3 (19/11/2026)
- Champ facultatif `tier` : "socle" (EDHEC/emlyon, défaut), "pont" (oraux HEC/ESCP, 400 exercices), "hp" (classique parisien / hors programme). Déduit de `conc` si absent.
- `ch` : en plus de 9-14 : 20 compléments d'algèbre linéaire · 21 réduction · 22 algèbre bilinéaire/euclidien · 23 polynômes · 30 VA discrètes/lois usuelles · 31 densité · 32 couples et n-uplets · 33 convergences/approximations/estimation.
- `dur` d'un exercice : 45 max si possible. Au-delà, l'app le découpe automatiquement selon les `min` des `qs` : donne donc des `min` réalistes par question, et des `id` de questions uniques et ordonnés.
- Priorité de transcription : classiques EDHEC/emlyon d'abord (exercices et questions), puis pont, puis hp.
