# Catalogue analyse (validé 19/11) — 🟡1 · 🟢2 · 🔵3 · ✓ = transcrit (rep/out)

## Déjà transcrits (37)
Exos : EDHEC 1993,1994,1995,1996,1997,1998,1999,2000,2001ex2,2002,2003ex1,2003ex2,2004,2005ex3,2006,2007,2008,2009,2010ex1,2013ex1,2014ex3,2015,2016,2017,2018s2ex3,2020ex1,2021,2025 · emlyon 2023ex1
Pbs : emlyon 2002,2003,2005,2010,2012,2021 · EDHEC 2013, 2020

## À transcrire — écrits
EDHEC exos : 🟡2018s1 Ex1 (implicite) · 🟢2018s3 Ex1 · 🟢2026 Ex2 (DL, trigo)
EDHEC pbs : 🟡1995 (rectangles) · 🟡2021 (I(p,q)) · 🟢1993 · 🟢2012 (Carleman) · 🟢2018s1 (Wallis+VA) · 🟢2022 (sh/ch) · 🟢2024 · 🟢2025 (Catalan) · 🔵2023 (n-périodiques)
emlyon : 🟡2004 P1 (Dirichlet/Laplace) · 🟡2011 exo Stirling · 🟡2013 P1 · 🟡2024 P2 (Gamma/Stirling) · 🟢1991 P2 · 🟢1996 P2 · 🟢1997 P2 · 🟢1999 P2 · 🟢2006 P1 · 🟢2007 P1 · 🟢2011 exo extremum · 🟢2016 P2 (η) · 🟢2017 P2 · 🟢2020 P1 · 🔵1990 P2 · 🔵1993 P2 · 🔵1995 P2 · 🔵2009 P1 · 🔵2015 P2 (Laplace, HP) · 🔵2018 P1 · 🔵2022 P2
ESSEC I : 🟡2001 (ζ(2)) · 🟢1994 (Gamma 2 param.) · 🟢2005 (Legendre-Fenchel) · 🟢2013 · 🟢2016 · 🔵1993 (π)
HEC-ESSEC I : 🟢2026 (S-convexes) · 🔵2023 (Stieltjes/Hausdorff)
HEC I : 🟢1991 (Gamma) · 🟢1994 (ln n!) · 🟢1997 (concavité) · 🟢2000 (optim. sous contrainte) · 🟢2005 (Γ, digamma) · 🟢2008 (min. n variables) · 🟢2009 (suites récurrentes linéaires) · 🔵1984 (Gamma) · 🔵1989 (ζ(2k), Bernoulli) · 🔵2002 (minimax) · 🔵2018 (à confirmer)
ESCP : 🟢1986 (suite somme) · 🟢1994 (Wallis) · 🔵1993 (involutions) · 🔵1995 (ζ) · 🔵2002 (quadrature de Gauss)
ESC (exos ★★★, thèmes à identifier) : 1998 Ex2 · 1999 Ex2 · 2000 Ex1 · 2001 Ex3 · 2002 Ex3 · 2003 Ex1 · 2006 Ex1 · 2006 Ex2

## À transcrire — oraux ESCP/HEC (PDF Vienney) pour notions sans annale
asymptote oblique par DL · prolongement de la dérivée · suites extraites · t↦f(x+th) · extremum global (ouvert convexe / convexe) · contrainte linéaire · sommes de Riemann · réciproque (te^t) · HP sans annale : d'Alembert, propriété du roi, théorème de la moyenne, Abel

## Écartés
HP/hors ECG : EDHEC 2001 Ex1, ESSEC 2010/2015 (équa diff), ESSEC 2018 (séries entières), HEC-ESSEC 2020, HEC 2001 (Volterra), ESCP 1988/2004 (équa diff). → algèbre : HEC 2017, ESSEC 2002/07/08/09/11, emlyon 2025 P1, HEC 2006/2007/2010/2013. → probas : HEC 2012, 2014, 2018 ; Maths II ; ESSEC II.
