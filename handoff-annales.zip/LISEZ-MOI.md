# Handoff : banque d'annales « Classiques d'annales » (Mehdi, ECG2, BCE 2027, objectif 18+)

## À LIRE EN PREMIER : stratégie et structure v3 (19/11/2026)
Stratégie complète : fichier projet `STRATEGIE-MATHS.md`. Diagnostic de Mehdi : DS types emlyon 10, EDHEC 8, Maths I HEC 2018 : 5 ; il bloque sur des questions classiques pas assez automatiques. Priorité de l'app : **classiques EDHEC/emlyon à automatiser**, puis pont (400 exercices triés, oraux HEC/ESCP), puis classiques hors programme parisiens (index HP du Méga répertoire Major Prépa). Les sujets complets Maths I/II ne sont PAS dans la banque (calendrier à part : samedi = un EDHEC/emlyon en 4 h ; un Maths I/II en mode étude toutes les ~3 semaines ; parisienne chaque semaine quand EDHEC/emlyon ≥ 13-14 régulier).

Structure implémentée dans `proto2/app.tpl.html` (v3) :
- **Blocs ≤ 45 min** : tout exercice dont la somme des `min` des questions dépasse 45 est découpé au chargement (`splitBlocs`) en parties « Q3c → Q4c » ; chaque bloc a son état de reprise (id `exId#k`). L'énoncé reste complet, un encadré dit quoi faire. Les problèmes restent suivis question par question ; chaque séance proposée est plafonnée à 45 min par problème. Avant : 14 exercices > 45 min ; après : 56 blocs, max 45.
- **Maîtrise** = 3 réussites d'affilée dont la dernière **dans le temps cible** (bouton « Fait dans le temps cible » avant d'enregistrer ; sinon n reste 2, reprise J+7).
- **Vu en classe** : pastilles par chapitre (réglage `SET.seenCh`, synchronisé). Les nouveaux exercices viennent des chapitres cochés ; rien coché = tout est proposé.
- **Tiers** : `tier` (socle = EDHEC/emlyon · pont = oraux, 400 exercices · hp = parisien) dérivé de `conc` si absent ; ordre des nouveaux : chapitre vu → tier → niveau ⭐ → chapitre fragile → année.
- **Chapitres couvrant tout le programme** (à ajuster si besoin) : analyse 9-14 ; algèbre 20 compléments d'algèbre linéaire, 21 réduction, 22 algèbre bilinéaire/euclidien, 23 polynômes ; probas 30 VA discrètes et lois usuelles, 31 densité, 32 couples et n-uplets, 33 convergences/approximations/estimation (découpage inspiré du programme officiel ECG 2A d'après Major Prépa/Groupe Réussite).
- Seul `index.html` change côté GitHub ; `contenu-analyse.json` est identique (inutile de le réimporter).
- Pas encore fait : découper le contenu des 27 problèmes en « classiques » à part ; page « sujets du samedi » ; états d'exercices déjà saisis sur un exercice découpé sont recopiés sur tous ses blocs (en mémoire, `migrateParts`).

## Objectif
App web perso (GitHub Pages + Firebase auth/Firestore + Gemini pour la correction de copies) construite autour des exercices et problèmes OFFICIELS d'annales BCE (jamais Ecricome). Menu : Exercices · Problèmes · Carnet (· Atelier, abandonné par Mehdi : c'est Claude qui transcrit). Exhaustivité visée : analyse (fait aux 2/3), puis probas, puis algèbre (classiques hors programme du répertoire Major Prépa inclus).

## Décisions de conception
- Exercices rangés par chapitre : 9 Fonctions, 10 Suites, 11 Intégration, 12 Séries, 13 Intégrales généralisées, 14 Plusieurs variables ; 20-23 algèbre ; 30-33 probas (voir v3).
- Niveaux par élément : lvl 1 🟡 indispensable · 2 🟢 très important · 3 🔵 important. Dans un problème : questions ★ (imp 1) = prioritaires (≈20-30 %).
- « Tombé dans » : liste dépliable (concours + année) construite par proto2/seen.py depuis le répertoire.
- Problèmes suivis question par question ; algorithme « quoi faire et quand » (score = importance × gravité × retard × bonus dépendances ; reprises J+3/10/30 pour faux/NT, J+7/21 pour partiel, acquis après 2 « juste » d'affilée ; budget : reprises → problème commencé → nouveau).
- Carnet : fiches générées seulement depuis ses copies corrigées, rédaction niveau concours.
- Programme ECG : trigonométrie OK ; équations différentielles et séries entières HORS programme ; Gamma OK ; extremum sous contrainte linéaire OK ; familles sommables hors programme.

## Règles de transcription (voir BRIEF_V2.md)
Énoncé mot pour mot ; corrigé fidèle au corrigé publié (erreurs corrigées + <p class="note">Note : …</p>) ; questions Python/Scilab supprimées ; si aucun corrigé : le rédiger et le signaler. Pas de backtick, pas de « ${ », \lt et \gt dans les formules.

## Reconstruire l'app (SANS agents, quelques secondes)
Dans le dossier /home/claude (recréer l'arborescence de ce zip) :
  python3 proto2/seen.py && python3 proto2/build.py && python3 build_app2.py
Entrées : rep/out/*.js (un fichier par lot : PROTO.push({...})). Sorties : app2/index.html, app2/manifest.json, app2/contenu-analyse.json.
Mehdi remplace index.html (et manifest si changé) sur GitHub (il doit renommer index_N.html en index.html, son Mac renomme les doublons) puis ré-importe contenu-analyse.json dans Réglages (jamais sur GitHub, contenu privé).
Dépôt : mehdilahloulao-lab/400-exos, URL https://mehdilahloulao-lab.github.io/400-exos/

## Reste à faire (analyse), par priorité
🟡 EDHEC 2018 s1 Ex1 · EDHEC 1995 pb · EDHEC 2021 pb · emlyon 2004 P1 · emlyon 2011 Stirling · emlyon 2013 P1 · emlyon 2024 P2 · ESSEC 2001
🟢 voir CATALOGUE_ANALYSE.md (section « À transcrire »), puis 🔵. Oraux ESCP/HEC pour 2 notions sans exercice.
Ensuite : probas, algèbre (listes à établir depuis le répertoire Major Prépa, même méthode avec index HP).
Sources : PDF de sujets/corrigés Major Prépa (liens dans rep/mp_links.tsv, major-prepa.com autorisé), PDF Vienney « Annales tout concours + corrigés » (sommaire rep/vienney/toc.txt ; ATTENTION il renumérote parfois les questions : suivre le sujet officiel si disponible), PDF « Oraux corrigés ESCP/HEC ».
À revérifier : numérotation « EDHEC 2018 (sujet 1/2/3) » des éléments existants (fichiers mal étiquetés chez Major Prépa) ; corrigés rédigés par Claude à relire : EDHEC 2020 pb fin 6a–8c, EDHEC 2026 Ex2, oral 2.38/2.34.

## Mode d'emploi économe (impératif : limite hebdomadaire de Mehdi)
Modèle Sonnet. Nouveaux éléments : privilégier des EXERCICES / questions classiques (dur ≤ 45), chapitres d'abord, pas de longs problèmes en priorité. Lots de 5 sujets max, déclenchés par lui. Aucun agent en parallèle. Lire les PDF en texte (pdftotext), en image seulement ce qui est illisible. Chaque lot : un seul index.html à remplacer + un contenu.json à importer. Ne jamais relancer de grosses vagues.
